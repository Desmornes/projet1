﻿namespace ProjetLabo
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label1DeleteTechnicien = new System.Windows.Forms.Label();
            this.buttonDeleteTechnicien = new System.Windows.Forms.Button();
            this.comboBoxDeleteTechnicien = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.labelDeleteUser = new System.Windows.Forms.Label();
            this.buttonDeleteUtilisateur = new System.Windows.Forms.Button();
            this.comboBoxDeleteUtilisateur = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxAddIdCompetence = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonAddCompetence = new System.Windows.Forms.Button();
            this.textBoxAddCompetence = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBoxAddCompetence = new System.Windows.Forms.ComboBox();
            this.comboBoxUpdateTechnicien = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBoxSetNiveauIntervTechnicien = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxSetFormationTechnicien = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.buttonSetTechnicien = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxAddNiveauIntervTechnicien = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxAddFormationTechnicien = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.buttonAddTechnicien = new System.Windows.Forms.Button();
            this.textBoxAddIdentiteTechnicien = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.buttonAddRegion = new System.Windows.Forms.Button();
            this.textBoxAddRegion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxAddRegion = new System.Windows.Forms.ComboBox();
            this.comboBoxUpdateUtilisateur = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBoxSetPasswordUtilisateur = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxSetLoginUtilisateur = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonSetUtilisateur = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonEstResponsableFalse = new System.Windows.Forms.RadioButton();
            this.radioButtonEstResponsableTrue = new System.Windows.Forms.RadioButton();
            this.textBoxAddNomUtilisateur = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxAddPasswordUtilisateur = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxAddLoginUtilisateur = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonAddUtilisateur = new System.Windows.Forms.Button();
            this.textBoxAddEmbaucheUtilisateur = new System.Windows.Forms.TextBox();
            this.textBoxAddMatriculeUtilisateur = new System.Windows.Forms.TextBox();
            this.textBoxAddIdentiteUtilisateur = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.labelIncidentsDeclaresUtilisateur = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.labelIncidentsEnChargeTechniciens = new System.Windows.Forms.Label();
            this.labelIncidentsResolusTechnicien = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.labelIncidentsResolus = new System.Windows.Forms.Label();
            this.labelIncidentsEnCharge = new System.Windows.Forms.Label();
            this.labelIncidentsDeclares = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Interface reponsables";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(43, 53);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1042, 571);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1034, 545);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Gestion du personnel";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(868, 500);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Page utilisateur";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label1DeleteTechnicien);
            this.groupBox6.Controls.Add(this.buttonDeleteTechnicien);
            this.groupBox6.Controls.Add(this.comboBoxDeleteTechnicien);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Location = new System.Drawing.Point(828, 224);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(182, 257);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Suppression d\'un technicien";
            // 
            // label1DeleteTechnicien
            // 
            this.label1DeleteTechnicien.AutoSize = true;
            this.label1DeleteTechnicien.Location = new System.Drawing.Point(26, 200);
            this.label1DeleteTechnicien.Name = "label1DeleteTechnicien";
            this.label1DeleteTechnicien.Size = new System.Drawing.Size(0, 13);
            this.label1DeleteTechnicien.TabIndex = 8;
            // 
            // buttonDeleteTechnicien
            // 
            this.buttonDeleteTechnicien.Location = new System.Drawing.Point(46, 140);
            this.buttonDeleteTechnicien.Name = "buttonDeleteTechnicien";
            this.buttonDeleteTechnicien.Size = new System.Drawing.Size(75, 23);
            this.buttonDeleteTechnicien.TabIndex = 7;
            this.buttonDeleteTechnicien.Text = "Supprimer";
            this.buttonDeleteTechnicien.UseVisualStyleBackColor = true;
            this.buttonDeleteTechnicien.Click += new System.EventHandler(this.buttonDeleteTechnicien_Click);
            // 
            // comboBoxDeleteTechnicien
            // 
            this.comboBoxDeleteTechnicien.FormattingEnabled = true;
            this.comboBoxDeleteTechnicien.Location = new System.Drawing.Point(19, 99);
            this.comboBoxDeleteTechnicien.Name = "comboBoxDeleteTechnicien";
            this.comboBoxDeleteTechnicien.Size = new System.Drawing.Size(132, 21);
            this.comboBoxDeleteTechnicien.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 77);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(168, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Choisir un technicien à supprimer :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.labelDeleteUser);
            this.groupBox5.Controls.Add(this.buttonDeleteUtilisateur);
            this.groupBox5.Controls.Add(this.comboBoxDeleteUtilisateur);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Location = new System.Drawing.Point(828, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(182, 211);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Suppression d\'un utilisateur";
            // 
            // labelDeleteUser
            // 
            this.labelDeleteUser.AutoSize = true;
            this.labelDeleteUser.Location = new System.Drawing.Point(26, 163);
            this.labelDeleteUser.Name = "labelDeleteUser";
            this.labelDeleteUser.Size = new System.Drawing.Size(0, 13);
            this.labelDeleteUser.TabIndex = 4;
            // 
            // buttonDeleteUtilisateur
            // 
            this.buttonDeleteUtilisateur.Location = new System.Drawing.Point(46, 117);
            this.buttonDeleteUtilisateur.Name = "buttonDeleteUtilisateur";
            this.buttonDeleteUtilisateur.Size = new System.Drawing.Size(75, 23);
            this.buttonDeleteUtilisateur.TabIndex = 3;
            this.buttonDeleteUtilisateur.Text = "Supprimer";
            this.buttonDeleteUtilisateur.UseVisualStyleBackColor = true;
            this.buttonDeleteUtilisateur.Click += new System.EventHandler(this.buttonDeleteUtilisateur_Click);
            // 
            // comboBoxDeleteUtilisateur
            // 
            this.comboBoxDeleteUtilisateur.FormattingEnabled = true;
            this.comboBoxDeleteUtilisateur.Location = new System.Drawing.Point(19, 77);
            this.comboBoxDeleteUtilisateur.Name = "comboBoxDeleteUtilisateur";
            this.comboBoxDeleteUtilisateur.Size = new System.Drawing.Size(132, 21);
            this.comboBoxDeleteUtilisateur.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(163, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Choisir un utilisateur à supprimer :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox10);
            this.groupBox4.Controls.Add(this.comboBoxUpdateTechnicien);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.textBoxSetNiveauIntervTechnicien);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.textBoxSetFormationTechnicien);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.buttonSetTechnicien);
            this.groupBox4.Location = new System.Drawing.Point(425, 271);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(378, 268);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Modification d\'un technicien";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label11);
            this.groupBox10.Controls.Add(this.textBoxAddIdCompetence);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.buttonAddCompetence);
            this.groupBox10.Controls.Add(this.textBoxAddCompetence);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Controls.Add(this.comboBoxAddCompetence);
            this.groupBox10.Location = new System.Drawing.Point(26, 103);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox10.Size = new System.Drawing.Size(329, 117);
            this.groupBox10.TabIndex = 44;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Ajouter une compétence";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(197, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 13);
            this.label11.TabIndex = 49;
            this.label11.Text = "ID :";
            // 
            // textBoxAddIdCompetence
            // 
            this.textBoxAddIdCompetence.Location = new System.Drawing.Point(223, 57);
            this.textBoxAddIdCompetence.Name = "textBoxAddIdCompetence";
            this.textBoxAddIdCompetence.Size = new System.Drawing.Size(81, 20);
            this.textBoxAddIdCompetence.TabIndex = 48;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(184, 90);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 50;
            this.label10.Text = "Nom : ";
            // 
            // buttonAddCompetence
            // 
            this.buttonAddCompetence.Location = new System.Drawing.Point(25, 85);
            this.buttonAddCompetence.Name = "buttonAddCompetence";
            this.buttonAddCompetence.Size = new System.Drawing.Size(111, 23);
            this.buttonAddCompetence.TabIndex = 47;
            this.buttonAddCompetence.Text = "Ajouter compétence";
            this.buttonAddCompetence.UseVisualStyleBackColor = true;
            // 
            // textBoxAddCompetence
            // 
            this.textBoxAddCompetence.Location = new System.Drawing.Point(223, 87);
            this.textBoxAddCompetence.Name = "textBoxAddCompetence";
            this.textBoxAddCompetence.Size = new System.Drawing.Size(81, 20);
            this.textBoxAddCompetence.TabIndex = 46;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(22, 28);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(138, 13);
            this.label40.TabIndex = 44;
            this.label40.Text = "Ajouter une compétence à :";
            // 
            // comboBoxAddCompetence
            // 
            this.comboBoxAddCompetence.FormattingEnabled = true;
            this.comboBoxAddCompetence.Location = new System.Drawing.Point(183, 28);
            this.comboBoxAddCompetence.Name = "comboBoxAddCompetence";
            this.comboBoxAddCompetence.Size = new System.Drawing.Size(121, 21);
            this.comboBoxAddCompetence.TabIndex = 45;
            // 
            // comboBoxUpdateTechnicien
            // 
            this.comboBoxUpdateTechnicien.FormattingEnabled = true;
            this.comboBoxUpdateTechnicien.Location = new System.Drawing.Point(190, 25);
            this.comboBoxUpdateTechnicien.Name = "comboBoxUpdateTechnicien";
            this.comboBoxUpdateTechnicien.Size = new System.Drawing.Size(121, 21);
            this.comboBoxUpdateTechnicien.TabIndex = 43;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(18, 28);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(159, 13);
            this.label37.TabIndex = 42;
            this.label37.Text = "Choisir un technicien à modifier :";
            // 
            // textBoxSetNiveauIntervTechnicien
            // 
            this.textBoxSetNiveauIntervTechnicien.Location = new System.Drawing.Point(202, 77);
            this.textBoxSetNiveauIntervTechnicien.Name = "textBoxSetNiveauIntervTechnicien";
            this.textBoxSetNiveauIntervTechnicien.Size = new System.Drawing.Size(100, 20);
            this.textBoxSetNiveauIntervTechnicien.TabIndex = 41;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(72, 80);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 13);
            this.label18.TabIndex = 40;
            this.label18.Text = "Niveau intervention :";
            // 
            // textBoxSetFormationTechnicien
            // 
            this.textBoxSetFormationTechnicien.Location = new System.Drawing.Point(202, 54);
            this.textBoxSetFormationTechnicien.Name = "textBoxSetFormationTechnicien";
            this.textBoxSetFormationTechnicien.Size = new System.Drawing.Size(100, 20);
            this.textBoxSetFormationTechnicien.TabIndex = 39;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(100, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "Formation :";
            // 
            // buttonSetTechnicien
            // 
            this.buttonSetTechnicien.Location = new System.Drawing.Point(151, 228);
            this.buttonSetTechnicien.Name = "buttonSetTechnicien";
            this.buttonSetTechnicien.Size = new System.Drawing.Size(75, 23);
            this.buttonSetTechnicien.TabIndex = 33;
            this.buttonSetTechnicien.Text = "Modifier";
            this.buttonSetTechnicien.UseVisualStyleBackColor = true;
            this.buttonSetTechnicien.Click += new System.EventHandler(this.buttonSetTechnicien_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxAddNiveauIntervTechnicien);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.textBoxAddFormationTechnicien);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.buttonAddTechnicien);
            this.groupBox3.Controls.Add(this.textBoxAddIdentiteTechnicien);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Location = new System.Drawing.Point(25, 271);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(378, 268);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ajout d\'un technicien";
            // 
            // textBoxAddNiveauIntervTechnicien
            // 
            this.textBoxAddNiveauIntervTechnicien.Location = new System.Drawing.Point(191, 146);
            this.textBoxAddNiveauIntervTechnicien.Name = "textBoxAddNiveauIntervTechnicien";
            this.textBoxAddNiveauIntervTechnicien.Size = new System.Drawing.Size(95, 20);
            this.textBoxAddNiveauIntervTechnicien.TabIndex = 26;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(55, 151);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(105, 13);
            this.label25.TabIndex = 25;
            this.label25.Text = "Niveau intervention :";
            // 
            // textBoxAddFormationTechnicien
            // 
            this.textBoxAddFormationTechnicien.Location = new System.Drawing.Point(191, 115);
            this.textBoxAddFormationTechnicien.Name = "textBoxAddFormationTechnicien";
            this.textBoxAddFormationTechnicien.Size = new System.Drawing.Size(95, 20);
            this.textBoxAddFormationTechnicien.TabIndex = 24;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(99, 118);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 13);
            this.label24.TabIndex = 23;
            this.label24.Text = "Formation :";
            // 
            // buttonAddTechnicien
            // 
            this.buttonAddTechnicien.BackColor = System.Drawing.Color.Transparent;
            this.buttonAddTechnicien.Location = new System.Drawing.Point(143, 188);
            this.buttonAddTechnicien.Name = "buttonAddTechnicien";
            this.buttonAddTechnicien.Size = new System.Drawing.Size(75, 23);
            this.buttonAddTechnicien.TabIndex = 18;
            this.buttonAddTechnicien.Text = "Ajouter";
            this.buttonAddTechnicien.UseVisualStyleBackColor = false;
            this.buttonAddTechnicien.Click += new System.EventHandler(this.buttonAddTechnicien_Click);
            // 
            // textBoxAddIdentiteTechnicien
            // 
            this.textBoxAddIdentiteTechnicien.Location = new System.Drawing.Point(191, 85);
            this.textBoxAddIdentiteTechnicien.Name = "textBoxAddIdentiteTechnicien";
            this.textBoxAddIdentiteTechnicien.Size = new System.Drawing.Size(95, 20);
            this.textBoxAddIdentiteTechnicien.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(110, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 12;
            this.label17.Text = "Identité :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.groupBox11);
            this.groupBox2.Controls.Add(this.comboBoxUpdateUtilisateur);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.textBoxSetPasswordUtilisateur);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.textBoxSetLoginUtilisateur);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.buttonSetUtilisateur);
            this.groupBox2.Location = new System.Drawing.Point(425, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(378, 257);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Modification d\'un utilisateur";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(210, 184);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(38, 13);
            this.label27.TabIndex = 49;
            this.label27.Text = "Nom : ";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.textBox1);
            this.groupBox11.Controls.Add(this.label26);
            this.groupBox11.Controls.Add(this.buttonAddRegion);
            this.groupBox11.Controls.Add(this.textBoxAddRegion);
            this.groupBox11.Controls.Add(this.label9);
            this.groupBox11.Controls.Add(this.comboBoxAddRegion);
            this.groupBox11.Location = new System.Drawing.Point(20, 102);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox11.Size = new System.Drawing.Size(329, 109);
            this.groupBox11.TabIndex = 45;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Ajouter une région";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(229, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(74, 20);
            this.textBox1.TabIndex = 48;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(200, 57);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 13);
            this.label26.TabIndex = 48;
            this.label26.Text = "ID :";
            // 
            // buttonAddRegion
            // 
            this.buttonAddRegion.Location = new System.Drawing.Point(31, 77);
            this.buttonAddRegion.Name = "buttonAddRegion";
            this.buttonAddRegion.Size = new System.Drawing.Size(93, 23);
            this.buttonAddRegion.TabIndex = 47;
            this.buttonAddRegion.Text = "Ajouter region";
            this.buttonAddRegion.UseVisualStyleBackColor = true;
            // 
            // textBoxAddRegion
            // 
            this.textBoxAddRegion.Location = new System.Drawing.Point(229, 54);
            this.textBoxAddRegion.Name = "textBoxAddRegion";
            this.textBoxAddRegion.Size = new System.Drawing.Size(74, 20);
            this.textBoxAddRegion.TabIndex = 46;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Ajouter une région à :";
            // 
            // comboBoxAddRegion
            // 
            this.comboBoxAddRegion.FormattingEnabled = true;
            this.comboBoxAddRegion.Location = new System.Drawing.Point(182, 25);
            this.comboBoxAddRegion.Name = "comboBoxAddRegion";
            this.comboBoxAddRegion.Size = new System.Drawing.Size(121, 21);
            this.comboBoxAddRegion.TabIndex = 45;
            // 
            // comboBoxUpdateUtilisateur
            // 
            this.comboBoxUpdateUtilisateur.FormattingEnabled = true;
            this.comboBoxUpdateUtilisateur.Location = new System.Drawing.Point(195, 25);
            this.comboBoxUpdateUtilisateur.Name = "comboBoxUpdateUtilisateur";
            this.comboBoxUpdateUtilisateur.Size = new System.Drawing.Size(121, 21);
            this.comboBoxUpdateUtilisateur.TabIndex = 24;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(11, 27);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(154, 13);
            this.label35.TabIndex = 23;
            this.label35.Text = "Choisir un utilisateur à modifier :";
            // 
            // textBoxSetPasswordUtilisateur
            // 
            this.textBoxSetPasswordUtilisateur.Location = new System.Drawing.Point(204, 77);
            this.textBoxSetPasswordUtilisateur.Name = "textBoxSetPasswordUtilisateur";
            this.textBoxSetPasswordUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxSetPasswordUtilisateur.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Mot de passe :";
            // 
            // textBoxSetLoginUtilisateur
            // 
            this.textBoxSetLoginUtilisateur.Location = new System.Drawing.Point(204, 55);
            this.textBoxSetLoginUtilisateur.Name = "textBoxSetLoginUtilisateur";
            this.textBoxSetLoginUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxSetLoginUtilisateur.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(75, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Identifiant (login) :";
            // 
            // buttonSetUtilisateur
            // 
            this.buttonSetUtilisateur.Location = new System.Drawing.Point(151, 218);
            this.buttonSetUtilisateur.Name = "buttonSetUtilisateur";
            this.buttonSetUtilisateur.Size = new System.Drawing.Size(75, 23);
            this.buttonSetUtilisateur.TabIndex = 18;
            this.buttonSetUtilisateur.Text = "Modifier";
            this.buttonSetUtilisateur.UseVisualStyleBackColor = true;
            this.buttonSetUtilisateur.Click += new System.EventHandler(this.buttonSetUtilisateur_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonEstResponsableFalse);
            this.groupBox1.Controls.Add(this.radioButtonEstResponsableTrue);
            this.groupBox1.Controls.Add(this.textBoxAddNomUtilisateur);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.textBoxAddPasswordUtilisateur);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxAddLoginUtilisateur);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.buttonAddUtilisateur);
            this.groupBox1.Controls.Add(this.textBoxAddEmbaucheUtilisateur);
            this.groupBox1.Controls.Add(this.textBoxAddMatriculeUtilisateur);
            this.groupBox1.Controls.Add(this.textBoxAddIdentiteUtilisateur);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(25, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 257);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ajout d\'un utilisateur";
            // 
            // radioButtonEstResponsableFalse
            // 
            this.radioButtonEstResponsableFalse.AutoSize = true;
            this.radioButtonEstResponsableFalse.Location = new System.Drawing.Point(154, 182);
            this.radioButtonEstResponsableFalse.Name = "radioButtonEstResponsableFalse";
            this.radioButtonEstResponsableFalse.Size = new System.Drawing.Size(132, 17);
            this.radioButtonEstResponsableFalse.TabIndex = 15;
            this.radioButtonEstResponsableFalse.TabStop = true;
            this.radioButtonEstResponsableFalse.Text = "n\'est pas Responsable";
            this.radioButtonEstResponsableFalse.UseVisualStyleBackColor = true;
            // 
            // radioButtonEstResponsableTrue
            // 
            this.radioButtonEstResponsableTrue.AutoSize = true;
            this.radioButtonEstResponsableTrue.Location = new System.Drawing.Point(28, 182);
            this.radioButtonEstResponsableTrue.Name = "radioButtonEstResponsableTrue";
            this.radioButtonEstResponsableTrue.Size = new System.Drawing.Size(104, 17);
            this.radioButtonEstResponsableTrue.TabIndex = 14;
            this.radioButtonEstResponsableTrue.TabStop = true;
            this.radioButtonEstResponsableTrue.Text = "est Responsable";
            this.radioButtonEstResponsableTrue.UseVisualStyleBackColor = true;
            // 
            // textBoxAddNomUtilisateur
            // 
            this.textBoxAddNomUtilisateur.Location = new System.Drawing.Point(154, 53);
            this.textBoxAddNomUtilisateur.Name = "textBoxAddNomUtilisateur";
            this.textBoxAddNomUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddNomUtilisateur.TabIndex = 13;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 56);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 13);
            this.label22.TabIndex = 12;
            this.label22.Text = "Nom complet :";
            // 
            // textBoxAddPasswordUtilisateur
            // 
            this.textBoxAddPasswordUtilisateur.Location = new System.Drawing.Point(154, 147);
            this.textBoxAddPasswordUtilisateur.Name = "textBoxAddPasswordUtilisateur";
            this.textBoxAddPasswordUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddPasswordUtilisateur.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(38, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Mot de passe :";
            // 
            // textBoxAddLoginUtilisateur
            // 
            this.textBoxAddLoginUtilisateur.Location = new System.Drawing.Point(154, 125);
            this.textBoxAddLoginUtilisateur.Name = "textBoxAddLoginUtilisateur";
            this.textBoxAddLoginUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddLoginUtilisateur.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Identifiant (login) :";
            // 
            // buttonAddUtilisateur
            // 
            this.buttonAddUtilisateur.Location = new System.Drawing.Point(143, 218);
            this.buttonAddUtilisateur.Name = "buttonAddUtilisateur";
            this.buttonAddUtilisateur.Size = new System.Drawing.Size(75, 23);
            this.buttonAddUtilisateur.TabIndex = 7;
            this.buttonAddUtilisateur.Text = "Ajouter";
            this.buttonAddUtilisateur.UseVisualStyleBackColor = true;
            this.buttonAddUtilisateur.Click += new System.EventHandler(this.buttonAddUtilisateur_Click);
            // 
            // textBoxAddEmbaucheUtilisateur
            // 
            this.textBoxAddEmbaucheUtilisateur.Location = new System.Drawing.Point(154, 99);
            this.textBoxAddEmbaucheUtilisateur.Name = "textBoxAddEmbaucheUtilisateur";
            this.textBoxAddEmbaucheUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddEmbaucheUtilisateur.TabIndex = 6;
            // 
            // textBoxAddMatriculeUtilisateur
            // 
            this.textBoxAddMatriculeUtilisateur.Location = new System.Drawing.Point(154, 77);
            this.textBoxAddMatriculeUtilisateur.Name = "textBoxAddMatriculeUtilisateur";
            this.textBoxAddMatriculeUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddMatriculeUtilisateur.TabIndex = 5;
            // 
            // textBoxAddIdentiteUtilisateur
            // 
            this.textBoxAddIdentiteUtilisateur.Location = new System.Drawing.Point(154, 29);
            this.textBoxAddIdentiteUtilisateur.Name = "textBoxAddIdentiteUtilisateur";
            this.textBoxAddIdentiteUtilisateur.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddIdentiteUtilisateur.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Date d\'embauche :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Matricule :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Identité :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1034, 545);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Visualisation des statistiques";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(851, 463);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Page utilisateur";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.labelIncidentsDeclaresUtilisateur);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Location = new System.Drawing.Point(520, 254);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(305, 112);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Statistiques sur les utilisateurs";
            // 
            // labelIncidentsDeclaresUtilisateur
            // 
            this.labelIncidentsDeclaresUtilisateur.AutoSize = true;
            this.labelIncidentsDeclaresUtilisateur.Location = new System.Drawing.Point(164, 54);
            this.labelIncidentsDeclaresUtilisateur.Name = "labelIncidentsDeclaresUtilisateur";
            this.labelIncidentsDeclaresUtilisateur.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsDeclaresUtilisateur.TabIndex = 6;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(38, 54);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(99, 13);
            this.label36.TabIndex = 5;
            this.label36.Text = "Incidents déclarés :";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.labelIncidentsEnChargeTechniciens);
            this.groupBox8.Controls.Add(this.labelIncidentsResolusTechnicien);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Location = new System.Drawing.Point(520, 96);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(305, 125);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Statistiques sur les techniciens";
            // 
            // labelIncidentsEnChargeTechniciens
            // 
            this.labelIncidentsEnChargeTechniciens.AutoSize = true;
            this.labelIncidentsEnChargeTechniciens.Location = new System.Drawing.Point(189, 48);
            this.labelIncidentsEnChargeTechniciens.Name = "labelIncidentsEnChargeTechniciens";
            this.labelIncidentsEnChargeTechniciens.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsEnChargeTechniciens.TabIndex = 4;
            // 
            // labelIncidentsResolusTechnicien
            // 
            this.labelIncidentsResolusTechnicien.AutoSize = true;
            this.labelIncidentsResolusTechnicien.Location = new System.Drawing.Point(148, 82);
            this.labelIncidentsResolusTechnicien.Name = "labelIncidentsResolusTechnicien";
            this.labelIncidentsResolusTechnicien.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsResolusTechnicien.TabIndex = 3;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(38, 82);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(92, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "Incidents résolus :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(38, 48);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(126, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Incidents pris en charge :";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.labelIncidentsResolus);
            this.groupBox7.Controls.Add(this.labelIncidentsEnCharge);
            this.groupBox7.Controls.Add(this.labelIncidentsDeclares);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Location = new System.Drawing.Point(191, 96);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(305, 270);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Statistiques sur les incidents";
            // 
            // labelIncidentsResolus
            // 
            this.labelIncidentsResolus.AutoSize = true;
            this.labelIncidentsResolus.Location = new System.Drawing.Point(142, 149);
            this.labelIncidentsResolus.Name = "labelIncidentsResolus";
            this.labelIncidentsResolus.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsResolus.TabIndex = 7;
            // 
            // labelIncidentsEnCharge
            // 
            this.labelIncidentsEnCharge.AutoSize = true;
            this.labelIncidentsEnCharge.Location = new System.Drawing.Point(178, 116);
            this.labelIncidentsEnCharge.Name = "labelIncidentsEnCharge";
            this.labelIncidentsEnCharge.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsEnCharge.TabIndex = 6;
            // 
            // labelIncidentsDeclares
            // 
            this.labelIncidentsDeclares.AutoSize = true;
            this.labelIncidentsDeclares.Location = new System.Drawing.Point(151, 82);
            this.labelIncidentsDeclares.Name = "labelIncidentsDeclares";
            this.labelIncidentsDeclares.Size = new System.Drawing.Size(0, 13);
            this.labelIncidentsDeclares.TabIndex = 5;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(29, 149);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(92, 13);
            this.label30.TabIndex = 2;
            this.label30.Text = "Incidents résolus :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(29, 116);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(126, 13);
            this.label29.TabIndex = 1;
            this.label29.Text = "Incidents pris en charge :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(29, 82);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Incidents déclarés :";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 636);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBoxAddPasswordUtilisateur;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxAddLoginUtilisateur;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonAddUtilisateur;
        private System.Windows.Forms.TextBox textBoxAddEmbaucheUtilisateur;
        private System.Windows.Forms.TextBox textBoxAddMatriculeUtilisateur;
        private System.Windows.Forms.TextBox textBoxAddIdentiteUtilisateur;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxSetPasswordUtilisateur;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxSetLoginUtilisateur;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonSetUtilisateur;
        private System.Windows.Forms.Button buttonDeleteTechnicien;
        private System.Windows.Forms.ListBox listBoxTechnicienDelete;
        private System.Windows.Forms.ComboBox comboBoxDeleteTechnicien;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button buttonDeleteUtilisateur;
        private System.Windows.Forms.ComboBox comboBoxDeleteUtilisateur;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxSetNiveauIntervTechnicien;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxSetFormationTechnicien;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxLoginTechnicien;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxSetLoginTechnicien;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button buttonSetTechnicien;
        private System.Windows.Forms.TextBox textBoxAddNiveauIntervTechnicien;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBoxAddFormationTechnicien;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxAddPasswordTechnicien;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxAddLoginTechnicien;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button buttonAddTechnicien;
        private System.Windows.Forms.TextBox textBoxAddDateTechnicien;
        private System.Windows.Forms.TextBox textBoxAddIdentiteTechnicien;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label labelIncidentsResolusTechnicien;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label labelIncidentsResolus;
        private System.Windows.Forms.Label labelIncidentsEnCharge;
        private System.Windows.Forms.Label labelIncidentsDeclares;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label labelIncidentsDeclaresUtilisateur;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label labelIncidentsEnChargeTechniciens;
        private System.Windows.Forms.ComboBox comboBoxUpdateTechnicien;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBoxUpdateUtilisateur;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBoxAddNomTechnicien;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button buttonAddCompetence;
        private System.Windows.Forms.TextBox textBoxAddCompetence;
        private System.Windows.Forms.ComboBox comboBoxAddCompetence;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button buttonAddRegion;
        private System.Windows.Forms.TextBox textBoxAddRegion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxAddRegion;
        private System.Windows.Forms.TextBox textBoxAddNomUtilisateur;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton radioButtonEstResponsableFalse;
        private System.Windows.Forms.RadioButton radioButtonEstResponsableTrue;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelDeleteUser;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAddIdCompetence;
        private System.Windows.Forms.Label label1DeleteTechnicien;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
    }
}