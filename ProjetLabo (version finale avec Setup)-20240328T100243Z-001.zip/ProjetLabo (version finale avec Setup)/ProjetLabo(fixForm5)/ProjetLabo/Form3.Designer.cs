﻿namespace ProjetLabo
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxAddMaterielIdPersonnel = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxAddGarantie = new System.Windows.Forms.TextBox();
            this.textBoxAddDisque = new System.Windows.Forms.TextBox();
            this.textBoxAddDateAchat = new System.Windows.Forms.TextBox();
            this.textBoxAddMemoire = new System.Windows.Forms.TextBox();
            this.textBoxAddProc = new System.Windows.Forms.TextBox();
            this.textBoxAddId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonShowMateriel = new System.Windows.Forms.Button();
            this.listBoxShowMateriel = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxShowMateriel = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonDeleteMateriel = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxDeleteMateriel = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonShowIncident = new System.Windows.Forms.Button();
            this.listBoxShowIncident = new System.Windows.Forms.ListBox();
            this.comboBoxShowIncident = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonUpdateIncident = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxIdPhase = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.buttonAjouterPhase = new System.Windows.Forms.Button();
            this.textBoxTravailPhase = new System.Windows.Forms.TextBox();
            this.textBoxHeureFinPhase = new System.Windows.Forms.TextBox();
            this.textBoxHeureDebut = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.radioButtonCloturee = new System.Windows.Forms.RadioButton();
            this.radioButtonResolue = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxShowIncidentPriseEnCharge = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.buttonAjoutLogiciel = new System.Windows.Forms.Button();
            this.textBoxDateLogiciel = new System.Windows.Forms.TextBox();
            this.textBoxNomLogiciel = new System.Windows.Forms.TextBox();
            this.textBoxIdLogiciel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxLogiciel = new System.Windows.Forms.ComboBox();
            this.labelDeletedMateriel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Interface techniciens";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxAddMaterielIdPersonnel);
            this.groupBox1.Controls.Add(this.label);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBoxAddGarantie);
            this.groupBox1.Controls.Add(this.textBoxAddDisque);
            this.groupBox1.Controls.Add(this.textBoxAddDateAchat);
            this.groupBox1.Controls.Add(this.textBoxAddMemoire);
            this.groupBox1.Controls.Add(this.textBoxAddProc);
            this.groupBox1.Controls.Add(this.textBoxAddId);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(63, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 275);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ajout d\'un nouveau matériel";
            // 
            // textBoxAddMaterielIdPersonnel
            // 
            this.textBoxAddMaterielIdPersonnel.Location = new System.Drawing.Point(85, 198);
            this.textBoxAddMaterielIdPersonnel.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxAddMaterielIdPersonnel.Name = "textBoxAddMaterielIdPersonnel";
            this.textBoxAddMaterielIdPersonnel.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddMaterielIdPersonnel.TabIndex = 14;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(17, 201);
            this.label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(59, 13);
            this.label.TabIndex = 13;
            this.label.Text = "Affecter à :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(67, 232);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Ajouter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxAddGarantie
            // 
            this.textBoxAddGarantie.Location = new System.Drawing.Point(85, 167);
            this.textBoxAddGarantie.Name = "textBoxAddGarantie";
            this.textBoxAddGarantie.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddGarantie.TabIndex = 11;
            // 
            // textBoxAddDisque
            // 
            this.textBoxAddDisque.Location = new System.Drawing.Point(85, 141);
            this.textBoxAddDisque.Name = "textBoxAddDisque";
            this.textBoxAddDisque.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddDisque.TabIndex = 10;
            // 
            // textBoxAddDateAchat
            // 
            this.textBoxAddDateAchat.Location = new System.Drawing.Point(85, 112);
            this.textBoxAddDateAchat.Name = "textBoxAddDateAchat";
            this.textBoxAddDateAchat.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddDateAchat.TabIndex = 9;
            // 
            // textBoxAddMemoire
            // 
            this.textBoxAddMemoire.Location = new System.Drawing.Point(85, 88);
            this.textBoxAddMemoire.Name = "textBoxAddMemoire";
            this.textBoxAddMemoire.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddMemoire.TabIndex = 8;
            // 
            // textBoxAddProc
            // 
            this.textBoxAddProc.Location = new System.Drawing.Point(85, 60);
            this.textBoxAddProc.Name = "textBoxAddProc";
            this.textBoxAddProc.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddProc.TabIndex = 7;
            // 
            // textBoxAddId
            // 
            this.textBoxAddId.Location = new System.Drawing.Point(85, 37);
            this.textBoxAddId.Name = "textBoxAddId";
            this.textBoxAddId.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddId.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Garantie :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Disque :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Date d\'achat :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mémoire : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Processeur :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonShowMateriel);
            this.groupBox2.Controls.Add(this.listBoxShowMateriel);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.comboBoxShowMateriel);
            this.groupBox2.Location = new System.Drawing.Point(323, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(311, 275);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Consultation de matériel";
            // 
            // buttonShowMateriel
            // 
            this.buttonShowMateriel.Location = new System.Drawing.Point(111, 201);
            this.buttonShowMateriel.Name = "buttonShowMateriel";
            this.buttonShowMateriel.Size = new System.Drawing.Size(75, 23);
            this.buttonShowMateriel.TabIndex = 3;
            this.buttonShowMateriel.Text = "Consulter";
            this.buttonShowMateriel.UseVisualStyleBackColor = true;
            this.buttonShowMateriel.Click += new System.EventHandler(this.buttonShowMateriel_Click);
            // 
            // listBoxShowMateriel
            // 
            this.listBoxShowMateriel.FormattingEnabled = true;
            this.listBoxShowMateriel.Location = new System.Drawing.Point(27, 86);
            this.listBoxShowMateriel.Name = "listBoxShowMateriel";
            this.listBoxShowMateriel.Size = new System.Drawing.Size(251, 95);
            this.listBoxShowMateriel.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Choisir un matériel :";
            // 
            // comboBoxShowMateriel
            // 
            this.comboBoxShowMateriel.FormattingEnabled = true;
            this.comboBoxShowMateriel.Location = new System.Drawing.Point(157, 43);
            this.comboBoxShowMateriel.Name = "comboBoxShowMateriel";
            this.comboBoxShowMateriel.Size = new System.Drawing.Size(121, 21);
            this.comboBoxShowMateriel.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.labelDeletedMateriel);
            this.groupBox3.Controls.Add(this.buttonDeleteMateriel);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.comboBoxDeleteMateriel);
            this.groupBox3.Location = new System.Drawing.Point(1034, 83);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(208, 226);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Suppression de matériel";
            // 
            // buttonDeleteMateriel
            // 
            this.buttonDeleteMateriel.Location = new System.Drawing.Point(65, 168);
            this.buttonDeleteMateriel.Name = "buttonDeleteMateriel";
            this.buttonDeleteMateriel.Size = new System.Drawing.Size(75, 23);
            this.buttonDeleteMateriel.TabIndex = 3;
            this.buttonDeleteMateriel.Text = "Supprimer";
            this.buttonDeleteMateriel.UseVisualStyleBackColor = true;
            this.buttonDeleteMateriel.Click += new System.EventHandler(this.buttonDeleteMateriel_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Choisir un matériel :";
            // 
            // comboBoxDeleteMateriel
            // 
            this.comboBoxDeleteMateriel.FormattingEnabled = true;
            this.comboBoxDeleteMateriel.Location = new System.Drawing.Point(40, 103);
            this.comboBoxDeleteMateriel.Name = "comboBoxDeleteMateriel";
            this.comboBoxDeleteMateriel.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDeleteMateriel.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonShowIncident);
            this.groupBox4.Controls.Add(this.listBoxShowIncident);
            this.groupBox4.Controls.Add(this.comboBoxShowIncident);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(323, 383);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(311, 226);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Consultation des incidents";
            // 
            // buttonShowIncident
            // 
            this.buttonShowIncident.Location = new System.Drawing.Point(121, 188);
            this.buttonShowIncident.Name = "buttonShowIncident";
            this.buttonShowIncident.Size = new System.Drawing.Size(75, 23);
            this.buttonShowIncident.TabIndex = 3;
            this.buttonShowIncident.Text = "Consulter";
            this.buttonShowIncident.UseVisualStyleBackColor = true;
            this.buttonShowIncident.Click += new System.EventHandler(this.buttonShowIncident_Click);
            // 
            // listBoxShowIncident
            // 
            this.listBoxShowIncident.FormattingEnabled = true;
            this.listBoxShowIncident.Location = new System.Drawing.Point(27, 78);
            this.listBoxShowIncident.Name = "listBoxShowIncident";
            this.listBoxShowIncident.Size = new System.Drawing.Size(257, 95);
            this.listBoxShowIncident.TabIndex = 2;
            // 
            // comboBoxShowIncident
            // 
            this.comboBoxShowIncident.FormattingEnabled = true;
            this.comboBoxShowIncident.Location = new System.Drawing.Point(163, 39);
            this.comboBoxShowIncident.Name = "comboBoxShowIncident";
            this.comboBoxShowIncident.Size = new System.Drawing.Size(121, 21);
            this.comboBoxShowIncident.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Choisir un incident :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonUpdateIncident);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.radioButtonCloturee);
            this.groupBox5.Controls.Add(this.radioButtonResolue);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.comboBoxShowIncidentPriseEnCharge);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(678, 83);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(311, 511);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Prise en charge d\'un incident";
            // 
            // buttonUpdateIncident
            // 
            this.buttonUpdateIncident.Location = new System.Drawing.Point(124, 461);
            this.buttonUpdateIncident.Name = "buttonUpdateIncident";
            this.buttonUpdateIncident.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateIncident.TabIndex = 8;
            this.buttonUpdateIncident.Text = "Mettre à jour ";
            this.buttonUpdateIncident.UseVisualStyleBackColor = true;
            this.buttonUpdateIncident.Click += new System.EventHandler(this.buttonUpdateIncident_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxIdPhase);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.buttonAjouterPhase);
            this.groupBox6.Controls.Add(this.textBoxTravailPhase);
            this.groupBox6.Controls.Add(this.textBoxHeureFinPhase);
            this.groupBox6.Controls.Add(this.textBoxHeureDebut);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Location = new System.Drawing.Point(26, 216);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(257, 218);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Phase de travail effectuée :";
            // 
            // textBoxIdPhase
            // 
            this.textBoxIdPhase.Location = new System.Drawing.Point(128, 31);
            this.textBoxIdPhase.Name = "textBoxIdPhase";
            this.textBoxIdPhase.Size = new System.Drawing.Size(100, 20);
            this.textBoxIdPhase.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(85, 33);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "ID:";
            // 
            // buttonAjouterPhase
            // 
            this.buttonAjouterPhase.Location = new System.Drawing.Point(98, 180);
            this.buttonAjouterPhase.Name = "buttonAjouterPhase";
            this.buttonAjouterPhase.Size = new System.Drawing.Size(75, 23);
            this.buttonAjouterPhase.TabIndex = 8;
            this.buttonAjouterPhase.Text = "Ajouter";
            this.buttonAjouterPhase.UseVisualStyleBackColor = true;
            this.buttonAjouterPhase.Click += new System.EventHandler(this.buttonAjouterPhase_Click);
            // 
            // textBoxTravailPhase
            // 
            this.textBoxTravailPhase.Location = new System.Drawing.Point(128, 115);
            this.textBoxTravailPhase.Name = "textBoxTravailPhase";
            this.textBoxTravailPhase.Size = new System.Drawing.Size(100, 20);
            this.textBoxTravailPhase.TabIndex = 6;
            // 
            // textBoxHeureFinPhase
            // 
            this.textBoxHeureFinPhase.Location = new System.Drawing.Point(128, 84);
            this.textBoxHeureFinPhase.Name = "textBoxHeureFinPhase";
            this.textBoxHeureFinPhase.Size = new System.Drawing.Size(100, 20);
            this.textBoxHeureFinPhase.TabIndex = 5;
            // 
            // textBoxHeureDebut
            // 
            this.textBoxHeureDebut.Location = new System.Drawing.Point(128, 58);
            this.textBoxHeureDebut.Name = "textBoxHeureDebut";
            this.textBoxHeureDebut.Size = new System.Drawing.Size(100, 20);
            this.textBoxHeureDebut.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Travail effectué :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Heure de fin :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Heure de début :";
            // 
            // radioButtonCloturee
            // 
            this.radioButtonCloturee.AutoSize = true;
            this.radioButtonCloturee.Location = new System.Drawing.Point(178, 168);
            this.radioButtonCloturee.Name = "radioButtonCloturee";
            this.radioButtonCloturee.Size = new System.Drawing.Size(64, 17);
            this.radioButtonCloturee.TabIndex = 6;
            this.radioButtonCloturee.TabStop = true;
            this.radioButtonCloturee.Text = "Clôturée";
            this.radioButtonCloturee.UseVisualStyleBackColor = true;
            // 
            // radioButtonResolue
            // 
            this.radioButtonResolue.AutoSize = true;
            this.radioButtonResolue.Location = new System.Drawing.Point(59, 168);
            this.radioButtonResolue.Name = "radioButtonResolue";
            this.radioButtonResolue.Size = new System.Drawing.Size(64, 17);
            this.radioButtonResolue.TabIndex = 5;
            this.radioButtonResolue.TabStop = true;
            this.radioButtonResolue.Text = "Résolue";
            this.radioButtonResolue.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 140);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(123, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Etat de prise en charge :";
            // 
            // comboBoxShowIncidentPriseEnCharge
            // 
            this.comboBoxShowIncidentPriseEnCharge.FormattingEnabled = true;
            this.comboBoxShowIncidentPriseEnCharge.Location = new System.Drawing.Point(59, 82);
            this.comboBoxShowIncidentPriseEnCharge.Name = "comboBoxShowIncidentPriseEnCharge";
            this.comboBoxShowIncidentPriseEnCharge.Size = new System.Drawing.Size(195, 21);
            this.comboBoxShowIncidentPriseEnCharge.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(56, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Choisir un incident à prendre en charge :";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1083, 461);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Page utilisateur";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.buttonAjoutLogiciel);
            this.groupBox7.Controls.Add(this.textBoxDateLogiciel);
            this.groupBox7.Controls.Add(this.textBoxNomLogiciel);
            this.groupBox7.Controls.Add(this.textBoxIdLogiciel);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.comboBoxLogiciel);
            this.groupBox7.Location = new System.Drawing.Point(63, 386);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(220, 223);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Ajout d\'un logiciel";
            // 
            // buttonAjoutLogiciel
            // 
            this.buttonAjoutLogiciel.Location = new System.Drawing.Point(69, 185);
            this.buttonAjoutLogiciel.Name = "buttonAjoutLogiciel";
            this.buttonAjoutLogiciel.Size = new System.Drawing.Size(75, 23);
            this.buttonAjoutLogiciel.TabIndex = 8;
            this.buttonAjoutLogiciel.Text = "Ajouter";
            this.buttonAjoutLogiciel.UseVisualStyleBackColor = true;
            this.buttonAjoutLogiciel.Click += new System.EventHandler(this.buttonAjoutLogiciel_Click);
            // 
            // textBoxDateLogiciel
            // 
            this.textBoxDateLogiciel.Location = new System.Drawing.Point(129, 146);
            this.textBoxDateLogiciel.Name = "textBoxDateLogiciel";
            this.textBoxDateLogiciel.Size = new System.Drawing.Size(85, 20);
            this.textBoxDateLogiciel.TabIndex = 7;
            // 
            // textBoxNomLogiciel
            // 
            this.textBoxNomLogiciel.Location = new System.Drawing.Point(129, 120);
            this.textBoxNomLogiciel.Name = "textBoxNomLogiciel";
            this.textBoxNomLogiciel.Size = new System.Drawing.Size(85, 20);
            this.textBoxNomLogiciel.TabIndex = 6;
            // 
            // textBoxIdLogiciel
            // 
            this.textBoxIdLogiciel.Location = new System.Drawing.Point(129, 93);
            this.textBoxIdLogiciel.Name = "textBoxIdLogiciel";
            this.textBoxIdLogiciel.Size = new System.Drawing.Size(85, 20);
            this.textBoxIdLogiciel.TabIndex = 5;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 151);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "Date d\'installation :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(55, 123);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Nom :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(66, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "ID :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(64, 36);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Choisir un materiel :";
            // 
            // comboBoxLogiciel
            // 
            this.comboBoxLogiciel.FormattingEnabled = true;
            this.comboBoxLogiciel.Location = new System.Drawing.Point(50, 62);
            this.comboBoxLogiciel.Name = "comboBoxLogiciel";
            this.comboBoxLogiciel.Size = new System.Drawing.Size(121, 21);
            this.comboBoxLogiciel.TabIndex = 0;
            // 
            // labelDeletedMateriel
            // 
            this.labelDeletedMateriel.AutoSize = true;
            this.labelDeletedMateriel.Location = new System.Drawing.Point(29, 147);
            this.labelDeletedMateriel.Name = "labelDeletedMateriel";
            this.labelDeletedMateriel.Size = new System.Drawing.Size(0, 13);
            this.labelDeletedMateriel.TabIndex = 4;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1275, 628);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Consultation des incidents";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxAddGarantie;
        private System.Windows.Forms.TextBox textBoxAddDisque;
        private System.Windows.Forms.TextBox textBoxAddDateAchat;
        private System.Windows.Forms.TextBox textBoxAddMemoire;
        private System.Windows.Forms.TextBox textBoxAddProc;
        private System.Windows.Forms.TextBox textBoxAddId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonShowMateriel;
        private System.Windows.Forms.ListBox listBoxShowMateriel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxShowMateriel;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonDeleteMateriel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxDeleteMateriel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonShowIncident;
        private System.Windows.Forms.ListBox listBoxShowIncident;
        private System.Windows.Forms.ComboBox comboBoxShowIncident;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonUpdateIncident;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonAjouterPhase;
        private System.Windows.Forms.TextBox textBoxTravailPhase;
        private System.Windows.Forms.TextBox textBoxHeureFinPhase;
        private System.Windows.Forms.TextBox textBoxHeureDebut;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton radioButtonCloturee;
        private System.Windows.Forms.RadioButton radioButtonResolue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxShowIncidentPriseEnCharge;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxIdPhase;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBoxAddMaterielIdPersonnel;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxLogiciel;
        private System.Windows.Forms.TextBox textBoxDateLogiciel;
        private System.Windows.Forms.TextBox textBoxNomLogiciel;
        private System.Windows.Forms.TextBox textBoxIdLogiciel;
        private System.Windows.Forms.Button buttonAjoutLogiciel;
        private System.Windows.Forms.Label labelDeletedMateriel;
    }
}